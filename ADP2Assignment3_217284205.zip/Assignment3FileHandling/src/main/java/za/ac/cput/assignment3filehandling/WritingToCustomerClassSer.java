/**
 * ADP2 Assignment3: File Handling
 * Aquilla Williams
 * 217284205 
 * Due Date: 09/06/2021 8mp
 */
package za.ac.cput.assignment3filehandling;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class WritingToCustomerClassSer {
    
    private ObjectOutputStream output;
    Customer[] customerArray = new Customer[6];
    
    

    
    public void populateArray2(){
        
        customerArray[0] = new Customer("C150", "Luke", "Atmyass", "Bellville", "1981-01-27", 1520.50, false);
        customerArray[1] = new Customer("C130", "Stu", "Padassol", "Sea Point", "1987-05-18", 645.25, true);
        customerArray[2] = new Customer("C100", "Mike", "Rohsopht", "Bellville", "1993-01-24", 975.10, true);
        customerArray[3] = new Customer("C300", "Ivana.B", "Withew", "Langa", "1998-07-16", 1190.50, false);
        customerArray[4] = new Customer("C300", "Ivana.B", "Withew", "Langa", "1998-07-16", 1190.50, false);
        customerArray[5] = new Customer("C260", "Ima", "Stewpidas", "Atlantis", "2001-01-27", 1890.70, true);
    
}
    public void openFile(){
        try{
            output = new ObjectOutputStream( new FileOutputStream( "stakeholder.ser" ) ); 
            System.out.println("*** ser file created and opened for writing ***");               
        }
        catch (IOException ioe){
            System.out.println("error opening ser file: " + ioe.getMessage());
            System.exit(1);
        }
    }
    public void closeFile(){
        try{
        output.close( ); 
        }
        catch (IOException ioe){            
            System.out.println("error closing ser file: " + ioe.getMessage());
            System.exit(1);
        }        
    }        

public void writeToFile(){
    try{
        for(int i =0; i<customerArray.length; i++){
        output.writeObject(customerArray[i]);
        System.out.printf("object %d write ser file: \n",i);
    }
    }
       catch(IOException ioe){
             System.out.println("****error writing ser file" + ioe);
             
         }
         finally{
             closeFile();
             System.out.println("** file ser have closed");
         }
     }
public static void main(String[] args) throws IOException {
       WritingToCustomerClassSer obj = new WritingToCustomerClassSer();
       obj.populateArray2();
       obj.openFile();
       obj.writeToFile();
       obj.closeFile();
    }           


    
}
